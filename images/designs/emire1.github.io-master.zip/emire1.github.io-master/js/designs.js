const preloader = document.getElementById("preloader");

window.addEventListener('load', function () {
    preloader.style.visibility = "hidden";
})