var options = {
    strings: ['Emmanuel Mireku | Portfolio'],
    typeSpeed: 50,
    smartBackspace: true,
    backDelay: 800,
    loop: false,
    loopCount: 1,
    showCursor: false
}

var typed = new Typed('.intro', options);